﻿'use strict';
var dashboardApp = angular.module('dashboard', []);

dashboardApp.service("customAjaxService", function ($rootScope) {
    var res;
    return {
        callAjax: function (url, parameter) {
            //blockUI.start();
            if ($rootScope.$$phase != '$apply' && $rootScope.$$phase != '$digest') {
                $rootScope.$apply();
            }
            $.ajax({
                type: "POST",
                async: false,
                data: parameter,
                url: url,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (response) {
                    //blockUI.stop();
                    res = response;
                    if ($rootScope.$$phase != '$apply' && $rootScope.$$phase != '$digest') {
                        $rootScope.$apply();
                    }
                },
                failure: function (response) {
                    //blockUI.stop();
                    if ($rootScope.$$phase != '$apply' && $rootScope.$$phase != '$digest') {
                        $rootScope.$apply();
                    }
                },
                error: function (xhr, status, error) {
                    //blockUI.stop();
                    if ($rootScope.$$phase != '$apply' && $rootScope.$$phase != '$digest') {
                        $rootScope.$apply();
                    }
                }
            });
            return res;
        }
    };

});