﻿using Dashboard.Hackathon.IBusinessLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Dashboard.Hackathon.UI.Controllers
{
    public class DashboardController : Controller
    {
        private ITestResultManager TestResultManager;

        public DashboardController(ITestResultManager testResultManager)
        {
            TestResultManager = testResultManager;
        }

        public ActionResult Index()
        {
            return View();
        }

        public JsonResult GetTestResults()
        {
            return Json(TestResultManager.GetAllTestResults());
        }
    }
}
