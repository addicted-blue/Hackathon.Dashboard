﻿using Dashboard.Hackathon.BusinessLogic;
using Dashboard.Hackathon.IBusinessLogic;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Unity.Mvc4;

namespace Dashboard.Hackathon.UI.App_Start
{
    public static class UnityConfig
    {
        public static IUnityContainer InitilizeDepedency()
        {
            var container = BuildContainer();
            DependencyResolver.SetResolver(new UnityDependencyResolver(container));

            return container;
        }

        private static IUnityContainer BuildContainer()
        {
            var container = new UnityContainer();

            //container.RegisterType<ITestResultManager, TestResultManager>();
            container.LoadConfiguration();
            return container;
        }
    }
}