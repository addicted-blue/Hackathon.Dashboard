﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dashboard.Hackathon.Entities
{
    public class TestResult
    {
        public int TestResultId { get; set; }

        public string TestResultName { get; set; }

        public bool IsPassed { get; set; }

        //public int MyProperty { get; set; }
    }
}
