﻿using Dashboard.Hackathon.Entities;
using Dashboard.Hackathon.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dashboard.Hackathon.Repository
{
    internal class TestResultRepo : ITestResultRepo
    {
        List<Entities.TestResult> ITestResultRepo.GetAllTestResults()
        {
            return new List<TestResult>()
            {
                new TestResult()
                {
                    IsPassed = true,
                    TestResultId = 1,
                    TestResultName = "Test 1"
                },
                new TestResult()
                {
                    IsPassed = false,
                    TestResultId = 2,
                    TestResultName = "Test 2"
                },new TestResult()
                {
                    IsPassed = true,
                    TestResultId = 3,
                    TestResultName = "Test 3"
                },new TestResult()
                {
                    IsPassed = true,
                    TestResultId = 4,
                    TestResultName = "Test 4"
                },new TestResult()
                {
                    IsPassed = true,
                    TestResultId = 5,
                    TestResultName = "Test 5"
                },new TestResult()
                {
                    IsPassed = false,
                    TestResultId = 6,
                    TestResultName = "Test 6"
                },new TestResult()
                {
                    IsPassed = true,
                    TestResultId = 7,
                    TestResultName = "Test 7"
                },new TestResult()
                {
                    IsPassed = false,
                    TestResultId = 8,
                    TestResultName = "Test 8"
                },new TestResult()
                {
                    IsPassed = false,
                    TestResultId = 9,
                    TestResultName = "Test 9"
                },new TestResult()
                {
                    IsPassed = true,
                    TestResultId = 10,
                    TestResultName = "Test 10"
                },new TestResult()
                {
                    IsPassed = false,
                    TestResultId = 11,
                    TestResultName = "Test 11"
                },new TestResult()
                {
                    IsPassed = true,
                    TestResultId = 12,
                    TestResultName = "Test 12"
                },new TestResult()
                {
                    IsPassed = true,
                    TestResultId = 13,
                    TestResultName = "Test 13"
                },new TestResult()
                {
                    IsPassed = true,
                    TestResultId = 14,
                    TestResultName = "Test 14"
                },new TestResult()
                {
                    IsPassed = false,
                    TestResultId = 15,
                    TestResultName = "Test 15"
                },new TestResult()
                {
                    IsPassed = true,
                    TestResultId = 16,
                    TestResultName = "Test 16"
                },new TestResult()
                {
                    IsPassed = true,
                    TestResultId = 17,
                    TestResultName = "Test 17"
                },new TestResult()
                {
                    IsPassed = true,
                    TestResultId = 18,
                    TestResultName = "Test 18"
                },new TestResult()
                {
                    IsPassed = true,
                    TestResultId = 19,
                    TestResultName = "Test 19"
                },new TestResult()
                {
                    IsPassed = true,
                    TestResultId = 20,
                    TestResultName = "Test 20"
                },
            };
        }
    }
}
