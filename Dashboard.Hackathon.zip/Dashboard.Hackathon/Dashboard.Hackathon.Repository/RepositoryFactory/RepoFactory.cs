﻿using Dashboard.Hackathon.IRepository.IRepositoryFactory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dashboard.Hackathon.Repository.RepositoryFactory
{
    public class RepoFactory : IRepoFactory
    {

        public IRepository.ITestResultRepo GetTestResultRepository()
        {
            return new TestResultRepo();
        }
    }
}
