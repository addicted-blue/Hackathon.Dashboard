﻿using Dashboard.Hackathon.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dashboard.Hackathon.IBusinessLogic
{
    public interface ITestResultManager
    {
        List<TestResult> GetAllTestResults();
    }
}
