﻿using Dashboard.Hackathon.IBusinessLogic;
using Dashboard.Hackathon.IRepository;
using Dashboard.Hackathon.IRepository.IRepositoryFactory;
using Dashboard.Hackathon.Repository.RepositoryFactory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dashboard.Hackathon.BusinessLogic
{
    public class TestResultManager : ITestResultManager
    {
        private ITestResultRepo TestResultRepo;
        private IRepoFactory RepoFactory;

        public TestResultManager(RepoFactory repoFactory)
        {
            RepoFactory = repoFactory;
            TestResultRepo = RepoFactory.GetTestResultRepository();
        }

        public List<Entities.TestResult> GetAllTestResults()
        {
            return TestResultRepo.GetAllTestResults();
        }
    }
}
